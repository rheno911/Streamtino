// ============================================================
//  scrapers/cineby.js - Scraper para cineby.sc
// ============================================================
const cheerio = require("cheerio");
const { get } = require("../utils/http");
const { extractVideoUrl, extractIframes } = require("../utils/extractor");

const BASE = "https://cineby.sc";
const SOURCE = "Cineby";

async function search(query, type) {
  try {
    const url = `${BASE}/?s=${encodeURIComponent(query)}`;
    const res = await get(url);
    const $ = cheerio.load(res.data);
    const results = [];

    $(".film-list .film-item, .movies .movie-item, article.item").each((_, el) => {
      const title = $(el).find(".film-title, h2, h3, .title").first().text().trim();
      const link = $(el).find("a").first().attr("href") || "";
      const img = $(el).find("img").first().attr("src") || $(el).find("img").first().attr("data-src") || "";
      if (title && link) {
        results.push({ title, link: link.startsWith("http") ? link : BASE + link, img });
      }
    });

    return results;
  } catch (err) {
    console.error(`[${SOURCE}] Error en búsqueda:`, err.message);
    return [];
  }
}

async function getStreams(imdbId, type, season, episode) {
  try {
    // Busca por IMDb ID o título
    const searchUrl = `${BASE}/?s=${imdbId}`;
    const res = await get(searchUrl);
    const $ = cheerio.load(res.data);

    // Encuentra el enlace de la primera coincidencia
    const firstLink = $("a[href*='/pelicula/'], a[href*='/serie/'], .film-item a, article a").first().attr("href");
    if (!firstLink) return [];

    const pageUrl = firstLink.startsWith("http") ? firstLink : BASE + firstLink;

    // Para series, navega a la temporada/episodio
    let targetUrl = pageUrl;
    if (type === "series" && season && episode) {
      const epRes = await get(pageUrl);
      const ep$ = cheerio.load(epRes.data);
      // Busca selector de temporada/episodio
      const epLink = ep$(
        `a[href*="temporada-${season}"][href*="episodio-${episode}"], 
         a[href*="season-${season}"][href*="episode-${episode}"]`
      ).first().attr("href");
      if (epLink) targetUrl = epLink.startsWith("http") ? epLink : BASE + epLink;
    }

    const iframes = await extractIframes(targetUrl, BASE);
    const streams = [];

    for (const iframe of iframes.slice(0, 5)) {
      const videoUrl = await extractVideoUrl(iframe, targetUrl);
      if (videoUrl) {
        streams.push({
          name: SOURCE,
          title: `📺 ${SOURCE}\n${new URL(iframe).hostname}`,
          url: videoUrl,
          behaviorHints: { notWebReady: false },
        });
      }
    }

    return streams;
  } catch (err) {
    console.error(`[${SOURCE}] Error obteniendo streams:`, err.message);
    return [];
  }
}

async function getCatalog(type, skip = 0) {
  try {
    const page = Math.floor(skip / 20) + 1;
    const section = type === "movie" ? "peliculas" : "series";
    const url = `${BASE}/${section}/page/${page}/`;
    const res = await get(url);
    const $ = cheerio.load(res.data);
    const items = [];

    $("article.item, .film-item, .movie-item").each((_, el) => {
      const title = $(el).find(".film-title, h2, h3, .title").first().text().trim();
      const link = $(el).find("a").first().attr("href") || "";
      const img = $(el).find("img").attr("src") || $(el).find("img").attr("data-src") || "";
      const year = $(el).find(".year, .fecha").text().match(/\d{4}/)?.[0] || "";

      if (title && link) {
        items.push({
          id: `latam:cineby:${encodeURIComponent(link)}`,
          type,
          name: title,
          poster: img,
          year,
          source: SOURCE,
          sourceUrl: link.startsWith("http") ? link : BASE + link,
        });
      }
    });

    return items;
  } catch (err) {
    console.error(`[${SOURCE}] Error en catálogo:`, err.message);
    return [];
  }
}

module.exports = { search, getStreams, getCatalog, SOURCE, BASE };
