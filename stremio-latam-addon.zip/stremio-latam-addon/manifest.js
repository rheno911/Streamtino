// ============================================================
//  MANIFEST - Stremio LatAm Addon
// ============================================================
const manifest = {
  id: "community.stremio-latam-addon",
  version: "1.0.0",
  name: "LatAm Streams",
  description:
    "Streams en Español Latino desde Cineby, SoloLatino, TioPlus, La.Movie, Cinezo, TubiTV, DetodoPeliculas, PelisPedia, VerPeliculasUltra, LatAnime, EstrenosAnime, EntrePeliculasySeries, GnulaHD y más.",
  logo: "https://i.imgur.com/LCKlwkZ.png",
  background: "https://i.imgur.com/WwnXB3k.jpeg",
  types: ["movie", "series"],
  catalogs: [
    {
      type: "movie",
      id: "latam-movies",
      name: "LatAm Películas",
      extra: [
        { name: "search", isRequired: false },
        { name: "skip", isRequired: false },
      ],
    },
    {
      type: "series",
      id: "latam-series",
      name: "LatAm Series",
      extra: [
        { name: "search", isRequired: false },
        { name: "skip", isRequired: false },
      ],
    },
    {
      type: "movie",
      id: "latam-anime-movies",
      name: "LatAm Anime Películas",
      extra: [
        { name: "search", isRequired: false },
        { name: "skip", isRequired: false },
      ],
    },
    {
      type: "series",
      id: "latam-anime-series",
      name: "LatAm Anime Series",
      extra: [
        { name: "search", isRequired: false },
        { name: "skip", isRequired: false },
      ],
    },
  ],
  resources: ["catalog", "stream", "meta"],
  idPrefixes: ["tt", "latam:"],
  behaviorHints: {
    adult: false,
    p2p: false,
    configurable: false,
  },
};

module.exports = manifest;
