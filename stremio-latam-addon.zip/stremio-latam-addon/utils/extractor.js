// ============================================================
//  utils/extractor.js - Extractor de URLs de video desde iframes/embeds
// ============================================================
const { get } = require("./http");
const cheerio = require("cheerio");

// Regex para encontrar URLs de video directas en el HTML/JS de la página
const VIDEO_URL_PATTERNS = [
  /file\s*[:=]\s*["']([^"']+\.(?:mp4|m3u8|webm)[^"']*)/gi,
  /source\s*[:=]\s*["']([^"']+\.(?:mp4|m3u8|webm)[^"']*)/gi,
  /["'](https?:\/\/[^"']+\.(?:mp4|m3u8|webm)[^"']*)/gi,
  /hls\.loadSource\(["']([^"']+)/gi,
  /jwplayer\([^)]+\)\.setup\(\{[^}]*file\s*:\s*["']([^"']+)/gis,
  /player\.src\(\s*\{[^}]*src\s*:\s*["']([^"']+)/gis,
  /var\s+(?:url|src|source|file|stream)\s*=\s*["']([^"']+\.(?:mp4|m3u8)[^"']*)/gi,
];

/**
 * Extrae la URL de video desde una URL de embed
 * @param {string} embedUrl
 * @param {string} referer - URL del sitio padre
 * @returns {string|null}
 */
async function extractVideoUrl(embedUrl, referer = "") {
  try {
    const res = await get(embedUrl, {
      headers: {
        Referer: referer,
        Origin: new URL(referer || embedUrl).origin,
      },
    });

    const html = res.data;
    const videoUrl = findVideoUrl(html);
    if (videoUrl) return videoUrl;

    // Busca iframes anidados
    const $ = cheerio.load(html);
    const iframeSrc = $("iframe").first().attr("src");
    if (iframeSrc) {
      const fullIframe = iframeSrc.startsWith("http")
        ? iframeSrc
        : new URL(iframeSrc, embedUrl).href;
      return await extractVideoUrl(fullIframe, embedUrl);
    }

    return null;
  } catch (err) {
    console.error(`[Extractor] Error en ${embedUrl}:`, err.message);
    return null;
  }
}

/**
 * Busca una URL de video directa en texto HTML/JS
 */
function findVideoUrl(html) {
  for (const pattern of VIDEO_URL_PATTERNS) {
    pattern.lastIndex = 0;
    const match = pattern.exec(html);
    if (match && match[1]) {
      const url = match[1].trim();
      if (url.includes("http") && (url.includes(".m3u8") || url.includes(".mp4"))) {
        return url;
      }
    }
  }
  return null;
}

/**
 * Extrae todos los iframes de una página
 */
async function extractIframes(pageUrl, referer = "") {
  try {
    const res = await get(pageUrl, { headers: { Referer: referer } });
    const $ = cheerio.load(res.data);
    const iframes = [];

    $("iframe, [data-src]").each((_, el) => {
      const src = $(el).attr("src") || $(el).attr("data-src") || "";
      if (src && src.startsWith("http")) {
        iframes.push(src);
      } else if (src && src.startsWith("//")) {
        iframes.push("https:" + src);
      } else if (src) {
        try {
          iframes.push(new URL(src, pageUrl).href);
        } catch (_) {}
      }
    });

    return iframes;
  } catch (err) {
    console.error(`[Extractor] Error extrayendo iframes de ${pageUrl}:`, err.message);
    return [];
  }
}

module.exports = { extractVideoUrl, extractIframes, findVideoUrl };
