// ============================================================
//  utils/http.js - Cliente HTTP con reintentos y cabeceras
// ============================================================
const axios = require("axios");

// Cabeceras que simulan un navegador real para evitar bloqueos
const DEFAULT_HEADERS = {
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
  "Accept-Language": "es-MX,es;q=0.9,en-US;q=0.8,en;q=0.7",
  Accept:
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
  "Accept-Encoding": "gzip, deflate, br",
  Connection: "keep-alive",
  "Cache-Control": "no-cache",
  Pragma: "no-cache",
  "Sec-Fetch-Dest": "document",
  "Sec-Fetch-Mode": "navigate",
  "Sec-Fetch-Site": "none",
  "Sec-Fetch-User": "?1",
  "Upgrade-Insecure-Requests": "1",
};

/**
 * GET con reintentos automáticos
 * @param {string} url
 * @param {object} opts - opciones extra de axios
 * @param {number} retries - intentos máximos
 */
async function get(url, opts = {}, retries = 3) {
  const config = {
    method: "GET",
    url,
    headers: { ...DEFAULT_HEADERS, ...(opts.headers || {}) },
    timeout: opts.timeout || 12000,
    maxRedirects: 5,
    ...opts,
  };

  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const response = await axios(config);
      return response;
    } catch (err) {
      const isLast = attempt === retries;
      if (isLast) {
        throw err;
      }
      // espera exponencial entre reintentos
      await sleep(500 * attempt);
    }
  }
}

/**
 * POST con reintentos
 */
async function post(url, data = {}, opts = {}, retries = 3) {
  const config = {
    method: "POST",
    url,
    data,
    headers: {
      ...DEFAULT_HEADERS,
      "Content-Type": "application/x-www-form-urlencoded",
      ...(opts.headers || {}),
    },
    timeout: opts.timeout || 12000,
    ...opts,
  };

  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const response = await axios(config);
      return response;
    } catch (err) {
      if (attempt === retries) throw err;
      await sleep(500 * attempt);
    }
  }
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

module.exports = { get, post, sleep, DEFAULT_HEADERS };
